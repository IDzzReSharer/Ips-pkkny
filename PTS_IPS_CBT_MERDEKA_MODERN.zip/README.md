# PTS IPS • CBT Modern

APK latihan PTS IPS dengan 20 pilihan ganda + 5 essay, timer 60 menit, navigasi, konfirmasi submit, nilai PG, rekap benar/salah, dan penyimpanan jawaban essay selama sesi.

Materi dibuat umum untuk IPS SMP berbasis Kurikulum Merdeka, terutama tema globalisasi, kearifan lokal, perubahan sosial, ekonomi, dan literasi digital.

## Build
Upload seluruh isi folder ke GitHub, pastikan `.github/workflows/build.yml` ikut ter-upload.
Buka tab **Actions** → **Build Android APK** → **Run workflow**.
Setelah selesai, buka hasil workflow → **Artifacts** → `PTS-IPS-CBT-debug` → ambil `app-debug.apk`.

Catatan: nilai otomatis saat ini menghitung 20 PG (masing-masing 5 poin). Essay tersimpan dan ditampilkan sebagai jawaban untuk pemeriksaan manual.
