package com.javraxanect.ptsipscbt;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    TextView q, progress, timer, type;
    RadioGroup options;
    EditText essay;
    Button prev, next;
    int index=0, seconds=3600;
    String[] answers = new String[25];
    String[] essays = new String[25];

    String[][] data = {
      {"Globalisasi adalah proses yang ditandai oleh ....","A. meningkatnya keterhubungan antarwilayah dunia","B. berkurangnya komunikasi antarnegara","C. ditutupnya hubungan perdagangan","D. hilangnya seluruh kebudayaan lokal"},
      {"Salah satu contoh globalisasi di bidang komunikasi adalah ....","A. mengirim surat dengan burung","B. menggunakan video call lintas negara","C. berjalan kaki ke sekolah","D. menanam padi"},
      {"Sikap yang tepat menghadapi globalisasi adalah ....","A. menolak semua perubahan","B. menerima semua budaya tanpa seleksi","C. menyaring pengaruh sesuai nilai masyarakat","D. menghapus budaya lokal"},
      {"Kearifan lokal merupakan ....","A. pengetahuan dan nilai yang berkembang dalam masyarakat setempat","B. budaya yang selalu berasal dari luar negeri","C. aturan yang hanya berlaku di internet","D. teknologi terbaru"},
      {"Contoh kearifan lokal dalam menjaga lingkungan adalah ....","A. membuang sampah ke sungai","B. aturan adat menjaga hutan","C. menebang semua pohon","D. membakar lahan sembarangan"},
      {"Dampak positif globalisasi dalam pendidikan adalah ....","A. akses sumber belajar menjadi lebih luas","B. siswa tidak perlu belajar","C. buku menjadi tidak berguna sama sekali","D. sekolah tidak diperlukan"},
      {"Salah satu dampak negatif globalisasi adalah ....","A. pertukaran informasi lebih cepat","B. peluang kerja sama meningkat","C. munculnya perilaku konsumtif","D. pengetahuan bertambah"},
      {"Pelestarian budaya lokal dapat dilakukan dengan ....","A. mempelajari dan mengenalkan budaya daerah","B. mengejek bahasa daerah","C. melarang kesenian tradisional","D. mengganti semua tradisi"},
      {"Perdagangan antarnegara dapat meningkat karena globalisasi melalui ....","A. perkembangan transportasi dan teknologi","B. penutupan pelabuhan","C. larangan komunikasi","D. pengurangan informasi"},
      {"Salah satu cara menggunakan media sosial secara bijak adalah ....","A. membagikan semua berita tanpa cek","B. memeriksa sumber informasi sebelum membagikan","C. menyebarkan data pribadi orang","D. mengikuti semua tren"},
      {"Kerja sama ekonomi antarnegara dapat memberikan manfaat berupa ....","A. perluasan pasar dan pertukaran barang","B. berhentinya perdagangan","C. hilangnya semua pekerjaan","D. tertutupnya investasi"},
      {"Budaya lokal dapat menjadi identitas masyarakat karena ....","A. mencerminkan nilai dan sejarah suatu daerah","B. selalu berubah menjadi budaya asing","C. tidak memiliki hubungan dengan masyarakat","D. hanya digunakan untuk hiburan"},
      {"Contoh perubahan akibat globalisasi dalam bidang makanan adalah ....","A. semakin mudah menemukan makanan dari berbagai negara","B. semua makanan tradisional hilang otomatis","C. pasar menjadi tertutup","D. tidak ada inovasi makanan"},
      {"Sikap selektif terhadap budaya asing berarti ....","A. memilih unsur yang sesuai dengan nilai masyarakat","B. menerima semuanya","C. menolak semuanya","D. tidak mempelajari budaya lain"},
      {"Gotong royong merupakan nilai sosial yang dapat ....","A. memperkuat solidaritas masyarakat","B. menghilangkan kerja sama","C. memecah masyarakat","D. membuat masyarakat individualis"},
      {"Teknologi digital dapat membantu UMKM dengan cara ....","A. memperluas promosi dan pemasaran","B. membatasi calon pembeli","C. menghapus transaksi","D. melarang inovasi"},
      {"Jika informasi viral belum jelas kebenarannya, tindakan yang tepat adalah ....","A. langsung menyebarkannya","B. mengecek sumber dan fakta terlebih dahulu","C. mengubah isinya","D. mengirim ke semua grup"},
      {"Kearifan lokal penting dipertahankan karena ....","A. menjadi bagian identitas dan pengetahuan masyarakat","B. menghambat semua kemajuan","C. selalu bertentangan dengan teknologi","D. hanya berlaku di masa lalu"},
      {"Hubungan global yang semakin erat menuntut masyarakat untuk ....","A. memiliki kemampuan beradaptasi dan berpikir kritis","B. berhenti belajar","C. menolak teknologi","D. menghindari semua kerja sama"},
      {"Contoh memanfaatkan globalisasi tanpa meninggalkan budaya lokal adalah ....","A. mempromosikan kesenian daerah melalui platform digital","B. menghapus bahasa daerah","C. meninggalkan tradisi keluarga","D. melarang teknologi"}
    };
    String[] essayQ = {
      "Jelaskan pengertian globalisasi dengan bahasamu sendiri.",
      "Sebutkan tiga dampak positif globalisasi dalam kehidupan sehari-hari.",
      "Sebutkan dua cara yang dapat dilakukan pelajar untuk melestarikan budaya lokal.",
      "Mengapa kita perlu bersikap selektif terhadap pengaruh budaya asing?",
      "Berikan satu contoh pemanfaatan teknologi digital untuk mempromosikan kearifan lokal."
    };
    int[] key = {0,1,2,0,1,0,2,0,0,1,0,0,0,0,0,0,1,0,0,0};

    @Override public void onCreate(Bundle b){
      super.onCreate(b); setContentView(R.layout.activity_main);
      q=findViewById(R.id.tvQuestion); progress=findViewById(R.id.tvProgress); timer=findViewById(R.id.tvTimer);
      type=findViewById(R.id.tvType); options=findViewById(R.id.options); essay=findViewById(R.id.essay);
      prev=findViewById(R.id.btnPrev); next=findViewById(R.id.btnNext);
      prev.setOnClickListener(v->{save(); if(index>0){index--; show();}});
      next.setOnClickListener(v->{save(); if(index<24){index++; show();}else confirmSubmit();});
      show();
      new CountDownTimer(seconds*1000L,1000){ public void onTick(long m){seconds=(int)(m/1000); timer.setText(String.format(Locale.US,"%02d:%02d",seconds/60,seconds%60));}
        public void onFinish(){timer.setText("00:00"); confirmSubmit();}}.start();
    }
    void show(){
      progress.setText("Soal "+(index+1)+" dari 25");
      options.removeAllViews(); essay.setVisibility(View.GONE); options.setVisibility(View.VISIBLE);
      if(index<20){
        type.setText("PILIHAN GANDA"); q.setText(data[index][0]);
        for(int i=0;i<4;i++){RadioButton rb=new RadioButton(this); rb.setText(data[index][i+1]); rb.setTextSize(16); rb.setTextColor(Color.rgb(30,32,45)); rb.setPadding(8,18,8,18); options.addView(rb);}
        if(answers[index]!=null){for(int i=0;i<4;i++) if(answers[index].equals(""+i)) ((RadioButton)options.getChildAt(i)).setChecked(true);}
      } else {
        type.setText("ESSAY"); q.setText(essayQ[index-20]); options.setVisibility(View.GONE); essay.setVisibility(View.VISIBLE);
        essay.setText(essays[index]==null?"":essays[index]);
      }
      prev.setEnabled(index>0); next.setText(index==24?"Kirim Jawaban":"Berikutnya →");
    }
    void save(){
      if(index<20){int id=options.getCheckedRadioButtonId(); if(id!=-1) answers[index]=""+options.indexOfChild(findViewById(id));}
      else essays[index]=essay.getText().toString();
    }
    void confirmSubmit(){
      new AlertDialog.Builder(this).setTitle("Kirim jawaban?")
        .setMessage("Setelah dikirim, jawaban tidak dapat diubah. Lanjutkan?")
        .setNegativeButton("Periksa Lagi",null).setPositiveButton("Kirim", (d,w)->result()).show();
    }
    void result(){
      save(); int correct=0; for(int i=0;i<20;i++) if(answers[i]!=null && Integer.parseInt(answers[i])==key[i]) correct++;
      int score=correct*5;
      StringBuilder s=new StringBuilder();
      s.append("Nilai Pilihan Ganda: ").append(score).append("/100\n\n");
      s.append("Benar: ").append(correct).append("\nSalah: ").append(20-correct).append("\n\n");
      s.append("Essay: ").append("5 jawaban tersimpan untuk diperiksa.\n\n");
      s.append("Kunci PG:\n"); for(int i=0;i<20;i++) s.append(i+1).append(". ").append((char)('A'+key[i])).append(answers[i]!=null&&Integer.parseInt(answers[i])==key[i]?" ✓":"").append("\n");
      new AlertDialog.Builder(this).setTitle("Hasil PTS IPS").setMessage(s.toString()).setPositiveButton("Selesai",(d,w)->finish()).setCancelable(false).show();
    }
}